

First run tables.sql and then procedures.sql.

If new Installation, please reload default data in mail server manager UI (Restore server).
