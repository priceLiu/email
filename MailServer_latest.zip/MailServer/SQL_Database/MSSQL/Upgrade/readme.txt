

1) Run all appropriate upgrade scripts
2) At last run procedures.sql
